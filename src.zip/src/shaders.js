
var Str = (j) => String(j);
var StrF = (j) => j.toFixed(1);

var vertexShaderSource = (settings) => `
    precision highp float;
    attribute vec2 a_position;

    attribute vec2 a_texCoord;
    varying vec2 v_texCoord;

    uniform float u_width;
    uniform float u_height;
    uniform float u_flipY;
    
    void main() {
       // convert the rectangle from pixels to 0.0 to 1.0
       vec2 zeroToOne = a_position / vec2(u_width, u_height);
    
       // convert from 0->1 to 0->2
       vec2 zeroToTwo = zeroToOne * 2.0;
    
       // convert from 0->2 to -1->+1 (clipspace)
       vec2 clipSpace = zeroToTwo - 1.0;
    
       gl_Position = vec4(clipSpace * vec2(1, u_flipY), 0, 1);
    
       // pass the texCoord to the fragment shader
       // The GPU will interpolate this value between points.
       v_texCoord = a_texCoord;
    }`;


var fragmentShaderColorSource = (settings) => `

    #define PI radians(180.0)

    precision highp float;
            
    varying vec2 v_texCoord;

    // our texture
    uniform sampler2D u_image_color;

    uniform float u_colorSensitivity;
    uniform float u_colorMixRatio;
    uniform float u_colorCap;
    uniform float u_colorExponent;
    uniform float u_colorMixExponent;

    uniform int u_colorPattern;
    
    uniform float u_width;
    uniform float u_height;

    // the texCoords passed in from the vertex shader.

    
    vec2 modulo(vec2 X, vec2 Y) {
        return vec2(X - floor(X / Y) * Y);
    }

    float moduloF(float X, float Y) {
        return X - floor(X / Y) * Y;
    }

    float atan2(float x, float y)
    {
        if (abs(x) > abs(y)) {
            return atan(y, x);
        }
        else {
            return PI / 2.0 - atan(x, y);
        }
    }

    vec4 colorCurve(float phase) {

        float rad = 1.0 / sin(PI/6.0) * cos(PI/3.0) 
                        / cos(moduloF(phase+PI/4.0, 2.0*PI/3.0) - PI/3.0);

        float a = atan(sqrt(2.0));

        float q = cos(phase)*(1.0 + u_colorMixRatio*(rad - 1.0));
        float p = sin(phase)*(1.0 + u_colorMixRatio*(rad - 1.0));

        float cr = 1.0/3.0 + 1.0/sqrt(6.0) * (
            0.5 * q * (1.0 - cos(a))
            + 0.5 * p * (1.0 + cos(a))
        );
        float cg = 1.0/3.0 - 1.0/sqrt(6.0) * (
            0.5 * q * (1.0 + cos(a))
            + 0.5 * p * (1.0 - cos(a))
        );
        float cb = 1.0/3.0 + 1.0/sqrt(6.0) * (
            1.0 / sqrt(2.0) * (q - p) * sin(a)
        );

        float rescaling = 1.0 / pow(max(max(cr, cg), cb), u_colorMixExponent);
        return vec4(rescaling*cr, rescaling*cg, rescaling*cb, 1.0) ;
    }

    void main() {

        float height = ` + Str(1 / settings.valueDimensions) + `;
        int j = int(floor(v_texCoord.y / height));
        int rev_j = ` + Str(settings.valueDimensions-1) + ` - j;

        int isComplex = 0;
        
        vec4 data = texture2D(u_image_color, v_texCoord);

        vec4 color = vec4(0.5, 0.5, 0.5, 1.0);
        `
        
        +
        [...Array(settings.valueDimensions).keys()].map((j) =>
            `
            if (rev_j == ` + Str(j) + `) {
                `
                +
                ((eval(settings.displayedQuantity)[j].substring(0,2) === "1i") ?
                `isComplex = 1;`
                :
                `isComplex = 0;`)
                +
                `
                
            }`
        ).join("")
        +
        `
        if (isComplex == 0) {
            float u_raw = data.a;
            float u = sign(u_raw) * pow(u_colorSensitivity * abs(u_raw),u_colorExponent);
            float v = sign(u) * pow(u_colorMixRatio * abs(u),u_colorMixExponent);

            if (u_colorPattern == 0) {
                if (u >= 0.0) {
                    color = vec4(   (1.0 - u_colorCap * (1.0 / (1.0 + u))),
                                    (1.0 - u_colorCap * (1.0 / (1.0 + v))),
                                    1.0 - u_colorCap,
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   1.0 - u_colorCap, 
                                    (1.0 - u_colorCap * (1.0 / (1.0 - v))),
                                    (1.0 - u_colorCap * (1.0 / (1.0 - u))),
                                    1.0);
                }
            }
            else if (u_colorPattern == 1) {
                if (u >= 0.0) {
                    color = vec4(   1.0 - u_colorCap,
                                    (1.0 - u_colorCap * (1.0 / (1.0 + u))),
                                    (1.0 - u_colorCap * (1.0 / (1.0 + v))),
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   (1.0 - u_colorCap * (1.0 / (1.0 - u))), 
                                    1.0 - u_colorCap,
                                    (1.0 - u_colorCap * (1.0 / (1.0 - v))),
                                    1.0);
                }
            }
            else if (u_colorPattern == 2) {
                if (u >= 0.0) {
                    color = vec4(   (1.0 - u_colorCap * (1.0 / (1.0 + v))),
                                    (1.0 - u_colorCap * (1.0 / (1.0 + u))),
                                    1.0 - u_colorCap,
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   (1.0 - u_colorCap * (1.0 / (1.0 - v))),
                                    1.0 - u_colorCap,
                                    (1.0 - u_colorCap * (1.0 / (1.0 - u))), 
                                    1.0);
                }
            }
            else if (u_colorPattern == 3) {
                if (u >= 0.0) {
                    color = vec4(   u_colorCap * (1.0 / (1.0 + u)),
                                    u_colorCap * (1.0 / (1.0 + v)),
                                    u_colorCap,
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   u_colorCap, 
                                    u_colorCap * (1.0 / (1.0 - v)),
                                    u_colorCap * (1.0 / (1.0 - u)),
                                    1.0);
                }
            }
            else if (u_colorPattern == 4) {
                if (u >= 0.0) {
                    color = vec4(   u_colorCap * 1.0,
                                    u_colorCap * (1.0 / (1.0 + u)),
                                    u_colorCap * (1.0 / (1.0 + v)),
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   u_colorCap * (1.0 / (1.0 - u)),
                                    u_colorCap * 1.0,
                                    u_colorCap * (1.0 / (1.0 - v)),
                                    1.0);
                }
            }
            else if (u_colorPattern == 5) {
                if (u >= 0.0) {
                    color = vec4(   u_colorCap * (1.0 / (1.0 + v)),
                                    u_colorCap * (1.0 / (1.0 + u)),
                                    u_colorCap * 1.0,
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   u_colorCap * (1.0 / (1.0 - v)), 
                                    u_colorCap * 1.0,
                                    u_colorCap * (1.0 / (1.0 - u)),
                                    1.0);
                }
            }
        }
        if (isComplex == 1) {
            float real = data.r;
            float imag = data.a;
            float mag = sqrt(real*real + imag*imag);
            float phase = atan2(real, imag);

            float u = pow(u_colorSensitivity * abs(mag), u_colorExponent);

            color = vec4(1.0 - 1.0 / (1.0 + u), 
                        1.0 - 1.0 / (1.0 + u),
                        1.0 - 1.0 / (1.0 + u), 
                        1.0) * colorCurve(phase);
        }
                
        gl_FragColor = color;
        gl_FragColor = vec4(0.0,1.0,1.0,1.0);
    }`;

var fragmentShaderComputeSource = (settings) => `
    precision highp float;

    varying vec2 v_texCoord;
            
    // our texture
    uniform sampler2D u_image;
    uniform sampler2D u_image_input;

    uniform vec2 u_mouse;

    uniform float u_width;
    uniform float u_height;

    uniform float u_laplace;
    uniform float u_identity;
    uniform float u_derivative;
    uniform float u_cubic;
    uniform float u_noise;
    uniform float u_inputStrength;

    uniform float u_scaleX;
    uniform float u_offsetX;

    uniform float u_scaleY;
    uniform float u_offsetY;

    uniform float u_scaleT;

    uniform int u_boundaryCondition;

    uniform float u_randSeed;
    
    // the texCoords passed in from the vertex shader.

    float rand(vec2 co){
        return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
    }

    float gaussian(float a) {
        float res1 = rand(v_texCoord.xy * vec2(a + 10.0));
        res1 = rand(vec2(res1, u_randSeed));
        float res2 = rand(v_texCoord.xy * vec2(100.0));
        res2 = rand(vec2(res2, u_randSeed));
        float res3 = rand(v_texCoord.xy * vec2(1000.0));
        res3 = rand(vec2(res3, u_randSeed));
        float res4 = rand(v_texCoord.yx * vec2(a + 11.0));
        res4 = rand(vec2(res4, u_randSeed));
        float res5 = rand(v_texCoord.yx * vec2(101.0));
        res5 = rand(vec2(res5, u_randSeed));
        float res6 = rand(v_texCoord.yx * vec2(1001.0));
        res6 = rand(vec2(res6, u_randSeed));

        return (res1 + res2 + res3 - res4 - res5 - res6) / 6.0;
    }


    vec2 modulo(vec2 X, vec2 Y) {
        return vec2(X - floor(X / Y) * Y);
    }
    
    void main() {
        
        vec4 data = texture2D(u_image, v_texCoord);

        float force = 0.0;

        float x = 0.0;
        float y = 0.0;
        float X = 0.0;
        float Y = 0.0;

        vec2 shift = vec2(0.0, 0.0);

        float t = data.b;

    `
    + 
    `
        float height = ` + Str(1 / settings.valueDimensions) + `;

        int j = int(floor(v_texCoord.y / height));
        int rev_j = ` + Str(settings.valueDimensions-1) + ` - j;

    `
    + [...Array(settings.valueDimensions).keys()].map((j) =>
    ` 
        vec2 texCoord_` + Str(j+1) + ` = v_texCoord + vec2(0.0, `+ `(` + StrF(j) + ` - float(j)) * height);
        
    `).join("")
    + [...Array(settings.valueDimensions).keys()].map((j) =>
    `
        float u_` + Str(j+1) + ` = 0.0;
        float u_` + Str(j+1) + `_t = 0.0;
        float u_` + Str(j+1) + `_tt = 0.0;
        float u_` + Str(j+1) + `_x = 0.0;
        float u_` + Str(j+1) + `_y = 0.0;
        float u_` + Str(j+1) + `_xx = 0.0;
        float u_` + Str(j+1) + `_yy = 0.0;
        float u_` + Str(j+1) + `_xy = 0.0;
        float u_` + Str(j+1) + `_yx = 0.0;
        float noise_` + Str(j+1) + ` = 0.0;
        float Delta_u_` + Str(j+1) + ` = 0.0;
        
    `).join("")
    +
    `
        float A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W;
        vec2 pixelSize = vec2(1.0 / u_width, 1.0 / u_height);


        if  ((u_boundaryCondition == 0) 
            || ((u_boundaryCondition == 1) && ((texCoord_1.x > 0.6 * pixelSize.x) && (texCoord_1.y > 0.6 * pixelSize.y)
                                            && (texCoord_1.x < 1.0 - 0.4 * pixelSize.x) && (texCoord_1.y < height - 0.4 * pixelSize.y)))
            || ((u_boundaryCondition == 2) && (distance(texCoord_1, vec2(0.5, 0.5 * height)) < 0.5 * height - 1.0 * min(pixelSize.x, pixelSize.y)))
            || ((u_boundaryCondition == 3) && ((texCoord_1.x > 0.6 * pixelSize.x) && (texCoord_1.x < 1.0 - 0.4 * pixelSize.x)))) {
        `
        + [...Array(settings.valueDimensions).keys()].map((j) =>
            `
                shift = vec2(0, `+ StrF(settings.valueDimensions - 1 - j) + ` * height); 

                u_` + Str(j+1) + ` = texture2D(u_image, shift + modulo(texCoord_1, vec2(1.0,height))).r;
                u_` + Str(j+1) + `_t = texture2D(u_image, shift + modulo(texCoord_1, vec2(1.0,height))).g;

                float u_` + Str(j+1) + `_above = texture2D(u_image, shift + modulo(texCoord_1 + vec2(0, pixelSize.y), vec2(1.0,height))).r;
                float u_` + Str(j+1) + `_below = texture2D(u_image, shift + modulo(texCoord_1 + vec2(0, -pixelSize.y), vec2(1.0,height))).r;
                float u_` + Str(j+1) + `_right = texture2D(u_image, shift + modulo(texCoord_1 + vec2(pixelSize.x, 0), vec2(1.0,height))).r;
                float u_` + Str(j+1) + `_left = texture2D(u_image, shift + modulo(texCoord_1 + vec2(-pixelSize.x, 0), vec2(1.0,height))).r;
                float u_` + Str(j+1) + `_right_above = texture2D(u_image, shift + modulo(texCoord_1 + vec2(pixelSize.x, pixelSize.y), vec2(1.0,height))).r;
                float u_` + Str(j+1) + `_right_below = texture2D(u_image, shift + modulo(texCoord_1 + vec2(pixelSize.x, -pixelSize.y), vec2(1.0,height))).r;
                float u_` + Str(j+1) + `_left_above = texture2D(u_image, shift + modulo(texCoord_1 + vec2(-pixelSize.x, pixelSize.y), vec2(1.0,height))).r;
                float u_` + Str(j+1) + `_left_below = texture2D(u_image, shift + modulo(texCoord_1 + vec2(-pixelSize.x, -pixelSize.y), vec2(1.0,height))).r;

                float Delta_u_` + Str(j+1) + ` = (u_` + Str(j+1) + `_right - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_left) / (2.0 * u_scaleX)
                                + (u_` + Str(j+1) + `_above - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_below) / (2.0 * u_scaleY)
                                + (u_` + Str(j+1) + `_right_above - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_left_below) / (2.0 * sqrt(2.0) * u_scaleX)
                                + (u_` + Str(j+1) + `_left_above - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_right_below) / (2.0 * sqrt(2.0) * u_scaleY);
                
                if (u_noise != 0.0) {
                    noise_` + Str(j+1) + ` = gaussian(` + StrF(j) + `);
                }
        

                u_` + Str(j+1) + `_x = (u_` + Str(j+1) + `_right - u_` + Str(j+1) + `_left) / (2.0 * u_scaleX);
                u_` + Str(j+1) + `_y = (u_` + Str(j+1) + `_above - u_` + Str(j+1) + `_below) / (2.0 * u_scaleY);
                u_` + Str(j+1) + `_xx = (u_` + Str(j+1) + `_right - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_left) / u_scaleX;
                u_` + Str(j+1) + `_yy = (u_` + Str(j+1) + `_above - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_below) / u_scaleY;
                u_` + Str(j+1) + `_xy = (u_` + Str(j+1) + `_right_above - u_` + Str(j+1) + `_left_above - u_` + Str(j+1) + `_right_below + u_` + Str(j+1) + `_left_below) / (4.0 * u_scaleX);
                u_` + Str(j+1) + `_yx = u_` + Str(j+1) + `_xy;
                x = u_offsetX + (texCoord_1.x - 0.5) * u_width * u_scaleX;
                y = u_offsetY + (texCoord_1.y - 0.5 * height) * u_height * u_scaleY;

                X = texCoord_1.x * u_width * u_scaleX;
                Y = texCoord_1.y * u_height * u_scaleY;

            `).join("")
            + `
                force = u_inputStrength * texture2D(u_image_input, modulo(texCoord_1 + vec2(0.0, float(j) * height) 
                    + pixelSize * (u_mouse + vec2(0.5, 0.5) * vec2(u_width, u_height)), vec2(1.0,1.0))).b;
            `
            + (settings.equation).split("#")[0].replace(/(\r\n|\n|\r)/gm, "")
            + [...Array(settings.valueDimensions).keys()].map((j) =>
                `
                    if (rev_j == ` + Str(j) + `) {
                        `
                        +
                        (settings.equation).split("#")[j+1].replace(/(\r\n|\n|\r)/gm, "")
                        +
                        `u_` + Str(j+1) + `_t = u_` + Str(j+1) + `_t + u_scaleT * u_` + Str(j+1) + `_tt;
                        u_` + Str(j+1) + ` = u_` + Str(j+1) + ` + u_scaleT * u_` + Str(j+1) + `_t;

                        t += u_scaleT;
                        gl_FragColor = vec4(u_` + Str(j+1) + `, u_` + Str(j+1) + `_t, t, ` 
                        +
                        (eval(settings.displayedQuantity)[j].substring(0,2) === "1i" ?
                            eval(settings.displayedQuantity)[j].substring(2)
                            :
                            eval(settings.displayedQuantity)[j]
                        )
                        +`);
                    }
                `).join("")
            + `
            } 
        `
    +
    `
        else {
        `
        + [...Array(settings.valueDimensions).keys()].map((j) =>
        `
            if (j == ` + Str(j) + `) {
                u_` + Str(j+1) + `_tt = 0.0;
                u_` + Str(j+1) + `_t = 0.0;
                u_` + Str(j+1) + ` = 0.0;

                t += u_scaleT;
                gl_FragColor = vec4(u_` + Str(j+1) + `, u_` + Str(j+1) + `_t, t, 1.0);
            }`).join("")
    +   `}
        gl_FragColor = vec4(0.0,0.0,0.0,1.0);
    }`;


export {vertexShaderSource, fragmentShaderColorSource, fragmentShaderComputeSource}