import React, { useState, useMemo, useRef, useEffect } from 'react';
import{fillDefaultSettings} from './spec.js';
import {launch} from './launch.js';
import {SettingsBox} from './SettingsBox.js';

/*
import create from 'zustand';

const useStore = create((set, get) => ({
    x: 0,
    setX: (x) => set({ x }),
}))
*/

function importSettingsFromWindowHash() {
    if(window.location.hash) {
        return(JSON.parse(decodeURIComponent(window.location.hash.substring(1))));
    }
    else {
        return({});
    }
}

function exportSettingsToWindowHash(settings) {
    window.location.hash = encodeURIComponent(JSON.stringify(settings, null, 2));
}


function Sim(props) {
    
    const [settings, setSettings] = useState(fillDefaultSettings(importSettingsFromWindowHash())); 

    const [handleChanges, setHandleChanges] = useState();

    const [render, setRender] = useState(0);

    //const { x, setX } = useStore();

    const canvasRef = useRef(null);

    
    var canvas = useMemo(() => <canvas id='canvas' 
                                        style={{touchAction: "none",
                                                width: "70vw",
                                                height: "auto"}}
                                        width={settings.width} height={settings.height} ref={canvasRef} />, [render]);
    

    var setSettingsAndWindowHash = (newSettings) => {
        setSettings(newSettings);
        exportSettingsToWindowHash(newSettings);
    }
    useEffect(() => {
        var terminate = launch(canvasRef.current, settings, setSettingsAndWindowHash, () => setRender(render+1), setHandleChanges) ;
        // inside the launch function I am changing the handleChanges functions, 
        //depending on what the canvas.context is like
        return(() => {
            clearInterval(terminate)
        })
    }, [render]);

    return(
        <div id='Sim' style={{backgroundColor: "white"}}>
            {canvas}
            <SettingsBox    settings = {settings}   handleChanges = {handleChanges} />
        </div>
    );
}


export {Sim};