import './App.css';
import React, { useState } from 'react';
import {Sim} from './FakeSim.js';
import {colors} from './colors.js';
import {defaultSpecification} from './spec.js'

function App() {
  
    const [specification, setSpecification] = useState(defaultSpecification);

    return (
        <div style = {{backgroundColor: colors.gray,
                       color: colors.textWhite,
                       width: "100vw",
                       height: "100vh"}}>
            SimPDE!
            <Sim specification = {specification}
                setSpecification = {setSpecification}
            />
        </div>
		
  );
}

export default App;
