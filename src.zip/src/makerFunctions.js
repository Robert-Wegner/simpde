import {vertexShaderSource, fragmentShaderColorSource, fragmentShaderComputeSource} from './shaders.js';
import {specification} from './spec.js'

// helper function for loading shader sources
function setRectangle(gl, x, y, width, height) {
    var x1 = x;
    var x2 = x + width;
    var y1 = y;
    var y2 = y + height;
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
        x1, y1,
        x2, y1,
        x1, y2,
        x1, y2,
        x2, y1,
        x2, y2,
    ]), gl.STATIC_DRAW);
}


function createAndSetupTexture(gl) {
    var texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
 
    // Set up texture so we can render any size image and so we are
    // working with pixels.
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
 
    return texture;
}

function createShader(gl, type, source) {
    var shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    var success = gl.getShaderParameter(shader, gl.COMPILE_STATUS);
    if (success) {
        return shader;
    }
   
    console.log(gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
}


function createProgram(gl, vertexShader, fragmentShader) {
    var program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    var success = gl.getProgramParameter(program, gl.LINK_STATUS);
    if (success) {
        return program;
    }
   
    console.log(gl.getProgramInfoLog(program));
    gl.deleteProgram(program);
}

function makeTextures(gl, nb_textures, settings) {

    var width = settings.width;
    var height = settings.height;
    var N = settings.valueDimensions;
    var scaleX = settings.scaleX;
    var scaleY = settings.scaleY;

    var F = eval(
        specification.reduce((acc, spec) =>
        (spec.hasOwnProperty('uniformName') ? 
            acc.replace("/" + spec.uniformName + "/g", String(settings[spec.name]))
            : 
            acc),
        settings.initialDataFunction)
    );

    var F = eval(settings.initialDataFunction.replace(
        /u_laplace/g, String(settings.laplacian)
    ).replace(
        /u_identity/g, String(settings.identity)
    ).replace(
        /u_cubic/g, String(settings.cubic)
    ).replace(
        /u_derivative/g, String(settings.derivative)
    ).replace(
        /u_noise/g, String(settings.noise)
    ));

    var textures = [];
    var framebuffers = [];
    
    for (var k = 0; k < nb_textures; k++) {
        var texture = createAndSetupTexture(gl);
        textures.push(texture);
        
        var textureData = new Float32Array(4 * width * height);

        var h = height / N;
        for(var i = 0; i < width; i++) {
            for(var j = 0; j < height; j++) {
                var x = (i + 0.5 - width / 2)* scaleX;
                var p = Math.floor(Math.floor(j / h));
                var y = (h / 2 + p * h - j - 0.5) * scaleY;

                var X = x + width / 2 * scaleX;
                var Y = y + h / 2 * scaleX;
                var transformation = (Func) => [...Array(N).keys()].map((j) => (x,y) => Func(x,y)[j])
                var f = transformation(F)[p]
                
                var initialData = f(x,y);
                if (k == 0) {

                    textureData[j * width * 4 + i * 4 + 0] = initialData[0];
                    textureData[j * width * 4 + i * 4 + 1] = initialData[1];
                    textureData[j * width * 4 + i * 4 + 2] = 0.0;
                    textureData[j * width * 4 + i * 4 + 3] = 0.0;
                }
                else {
                    textureData[j * width * 4 + i * 4 + 0] = 0.0;
                    textureData[j * width * 4 + i * 4 + 1] = 0.0;
                    textureData[j * width * 4 + i * 4 + 2] = 0.0;
                    textureData[j * width * 4 + i * 4 + 3] = 0.0;
                }
                
            }
        }
        
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, width, height, 0, gl.RGBA, gl.FLOAT, textureData);
        
        // Create a framebuffer
        var fbo = gl.createFramebuffer();
        framebuffers.push(fbo);
        gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);

        // Attach a texture to it.
        var attachmentPoint = gl.COLOR_ATTACHMENT0;
        gl.framebufferTexture2D(gl.FRAMEBUFFER, attachmentPoint, gl.TEXTURE_2D, texture, 0);

        if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) {
            console.log("attachment error");
            if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) == gl.FRAMEBUFFER_INCOMPLETE_ATTACHMENT)  {
                console.log("incomplete attachment");
            }
        }
    }


    return {textures: textures, framebuffers: framebuffers};
}

function makeInputTexture(gl, width, height, radius) {

    var inputTexture = createAndSetupTexture(gl);
    var inputTextureData = new Float32Array(4 * width * height);

    for(var i = 0; i < height; i++) {
        for(var j = 0; j < width; j++) {
            inputTextureData[i * width * 4 + j * 4 + 0] = 0.0;
            inputTextureData[i * width * 4 + j * 4 + 1] = 0.0;

            var R_squared = Math.pow(radius,2);
            var r_squared = Math.pow((i - height/2), 2) + Math.pow((j - width/2), 2);
            if (r_squared < R_squared) {
                
                inputTextureData[i * width * 4 + j * 4 + 2] = Math.pow(2, -R_squared / (R_squared - r_squared));
            }
            else {
                inputTextureData[i * width * 4 + j * 4 + 2] = 0.0;
            }
            
            inputTextureData[i * width * 4 + j * 4 + 3] = 0.0;

        }
    }

    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, width, height, 0, gl.RGBA, gl.FLOAT, inputTextureData);

    return inputTexture;
}

function makeShaderPrograms(gl, width, height, settings) {
    // send the vertex positions to the GPU
    var vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    setRectangle(gl, 0, 0, width, height);

    // define vertex texcoords
    var texCoords = new Float32Array([
        0.0,  0.0,
        1.0,  0.0,
        0.0,  1.0,
        0.0,  1.0,
        1.0,  0.0,
        1.0,  1.0,
    ]);

    // send the vertex texcoords to the GPU
    var texcoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, texcoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, texCoords, gl.STATIC_DRAW);

    var vertexShader = createShader(gl, gl.VERTEX_SHADER, vertexShaderSource(settings));

    var fragmentShaderCompute = createShader(gl, gl.FRAGMENT_SHADER, fragmentShaderComputeSource(settings));
    var fragmentShaderColor = createShader(gl, gl.FRAGMENT_SHADER, fragmentShaderColorSource(settings));

    var shaderProgramCompute = createProgram(gl, vertexShader, fragmentShaderCompute);
    var shaderProgramColor = createProgram(gl, vertexShader, fragmentShaderColor);   

    var flipYLocation = gl.getUniformLocation(shaderProgramCompute, "u_flipY");
    gl.useProgram(shaderProgramCompute);
    gl.uniform1f(flipYLocation, 1.0);

    gl.useProgram(shaderProgramColor);
    flipYLocation = gl.getUniformLocation(shaderProgramColor, "u_flipY");
    gl.uniform1f(flipYLocation, 1.0);

    gl.useProgram(shaderProgramCompute);

    var positionAttribute = gl.getAttribLocation(shaderProgramCompute, "a_position");
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.enableVertexAttribArray(positionAttribute);
    gl.vertexAttribPointer(positionAttribute, 2, gl.FLOAT, false, 0, 0);

    var texcoordAttribute = gl.getAttribLocation(shaderProgramCompute, "a_texCoord");
    gl.bindBuffer(gl.ARRAY_BUFFER, texcoordBuffer);
    gl.enableVertexAttribArray(texcoordAttribute);
    gl.vertexAttribPointer(texcoordAttribute, 2, gl.FLOAT, false, 0, 0);

    gl.useProgram(shaderProgramColor);

    var positionAttribute = gl.getAttribLocation(shaderProgramColor, "a_position");
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.enableVertexAttribArray(positionAttribute);
    gl.vertexAttribPointer(positionAttribute, 2, gl.FLOAT, false, 0, 0);

    var texcoordAttribute = gl.getAttribLocation(shaderProgramColor, "a_texCoord");
    gl.bindBuffer(gl.ARRAY_BUFFER, texcoordBuffer);
    gl.enableVertexAttribArray(texcoordAttribute);
    gl.vertexAttribPointer(texcoordAttribute, 2, gl.FLOAT, false, 0, 0);

    return {shaderProgramCompute: shaderProgramCompute,
            shaderProgramColor: shaderProgramColor};
}


export {makeTextures, makeInputTexture, makeShaderPrograms};