import{specification} from './spec.js';
import {makeTextures, makeInputTexture, makeShaderPrograms} from './makerFunctions';


function launch(canvas, settings, setSettings, rerender, setHandleChanges){

    var width = settings.width;
    var height = settings.height;

    var gl = canvas.getContext("webgl2");

    if (!gl) {
        console.log('your browser/OS/drivers do not support WebGL2');
    } else {
        console.log('webgl2 works!');
    }
    gl.getExtension( 'EXT_color_buffer_float' );    
    
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);

    console.log(gl);
    var nb_textures = 3;
    var textures = [];
    var framebuffers = [];

    var {textures, framebuffers} = makeTextures(gl, nb_textures, settings);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    var inputTexture = makeInputTexture(gl, width, height, settings.inputRadius);

    var {shaderProgramCompute, shaderProgramColor} = makeShaderPrograms(gl, width, height, settings);


    var settingsUniformLocationsCompute = specification.filter(
        (spec) => (spec.shaderPrograms && spec.shaderPrograms.includes("compute"))
    ).map(
        (spec) => {return({ name: spec.name,
                            location: gl.getUniformLocation(shaderProgramCompute, spec.uniformName)})}
    );

    var settingsUniformLocationsColor = specification.filter(
        (spec) => (spec.shaderPrograms && spec.shaderPrograms.includes("color"))
    ).map(
        (spec) => {return({ name: spec.name,
                            location: gl.getUniformLocation(shaderProgramColor, spec.uniformName)})}
    );

    gl.useProgram(shaderProgramCompute);
    settingsUniformLocationsCompute.map((obj) => {
        if (settings[obj.name].type === "float") {
            gl.uniform1f(obj.location, settings[obj.name])
        }
        else if (settings[obj.name].type === "int") {
            gl.uniform1i(obj.location, settings[obj.name])
        }
    });

    gl.useProgram(shaderProgramColor);
    settingsUniformLocationsColor.map((obj) => {
        if (settings[obj.name].type === "float") {
            gl.uniform1f(obj.location, settings[obj.name])
        }
        else if (settings[obj.name].type === "int") {
            gl.uniform1i(obj.location, settings[obj.name])
        }
    });


    var otherUniformLocationsCompute = {
        randSeed: {uniformName: "u_randSeed",
                location: gl.getUniformLocation(shaderProgramCompute, "u_randSeed")},
        mouse: {uniformName: "u_mouse",
            location: gl.getUniformLocation(shaderProgramCompute, "u_mouse")},
        image: {uniformName: "u_image",
            location: gl.getUniformLocation(shaderProgramCompute, "u_image")},
        imageInput: {uniformName: "u_image_input",
            location: gl.getUniformLocation(shaderProgramCompute, "u_image_input")}
    };

    var otherUniformLocationsColor = {
        imageColor: {uniformName: "u_image_color",
            location: gl.getUniformLocation(shaderProgramColor, "u_image_color")}
    };

    gl.useProgram(shaderProgramCompute);
    gl.uniform1f(otherUniformLocationsCompute.randSeed.location, 0);
    gl.uniform2f(otherUniformLocationsCompute.mouse.location, 0, 0);
    gl.uniform1i(otherUniformLocationsCompute.image.location, 0);
    gl.uniform1i(otherUniformLocationsCompute.imageInput.location, 1);

    gl.useProgram(shaderProgramColor);
    gl.uniform1i(otherUniformLocationsColor.imageColor.location, 0);



    var toggle = 1.0;

    var mouseLocation = otherUniformLocationsCompute.mouse.location;
    var inputStrengthLocation = settingsUniformLocationsCompute.find((e) => e.name == "inputStrength").location;
    
    var onmousedown = function(e) {
        gl.useProgram(shaderProgramCompute);
        var X = e.clientX || e.targetTouches[0].clientX;
        var Y = e.clientY || e.targetTouches[0].clientY;
        var rect = canvas.getBoundingClientRect();
        var x = (X-rect.x) * width / rect.width;
        var y = (Y-rect.y) * height / rect.height;
        gl.uniform2f(mouseLocation, -x, y);
        gl.uniform1f(inputStrengthLocation, toggle * settings.inputStrength);
        toggle *= -1.0;
    }
    var onmouseup = function(e) {
        gl.useProgram(shaderProgramCompute);
        gl.uniform1f(inputStrengthLocation, 0.0);

    }
    var onmousemove = function(e) {
        gl.useProgram(shaderProgramCompute);
        var X = e.clientX || e.targetTouches[0].clientX;
        var Y = e.clientY || e.targetTouches[0].clientY;
        var rect = canvas.getBoundingClientRect();
        var x = (X-rect.x) * width / rect.width;
        var y = (Y-rect.y) * height / rect.height;
        gl.uniform2f(mouseLocation, -x, y);

    }

    canvas.onmousedown = onmousedown;
    canvas.onmousemove = onmousemove;
    canvas.onmouseup = onmouseup;
    if (window.navigator.msPointerEnabled) {
        canvas.addEventListener("MSPointerDown", onmousedown, false);
        canvas.addEventListener("MSPointerMove", onmousemove, false);
        canvas.addEventListener("MSPointerUp", onmouseup, false);
    }
    else {
        canvas.addEventListener("touchstart", onmousedown, false);
        canvas.addEventListener("touchmove", onmousemove, false);
        canvas.addEventListener("touchend", onmouseup, false);
    }



    var time = 0;
    gl.useProgram(shaderProgramCompute);

    gl.bindTexture(gl.TEXTURE_2D, textures[time % 2]);
    gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffers[(time + 1) % 2]);
    
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, width, height);
    gl.drawArrays(gl.TRIANGLES, 0, 6);

    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, inputTexture);

    var update = function(){
        //console.time();
        gl.useProgram(shaderProgramCompute);
        if (settings.noise > 0.0) {
            gl.uniform1f(otherUniformLocationsCompute.randSeed.location, Math.random());
        }

        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, textures[time % 2]);
        
        
        gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffers[(time + 1) % 2]);
        gl.viewport(0, 0, width, height);
        gl.drawArrays(gl.TRIANGLES, 0, 6);

        //console.timeEnd();
        //console.time();
        gl.useProgram(shaderProgramColor);

        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, textures[(time + 1) % 2]);
        

        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        gl.viewport(0, 0, width, height);
        gl.drawArrays(gl.TRIANGLES, 0, 6);

        //gl.clearColor(0.0, Math.cos(time / 300), 0.0, 1.0);
        // Clear the context with the newly set color. This is
        // the function call that actually does the drawing.
        //gl.clear(gl.COLOR_BUFFER_BIT);


        //console.timeEnd();
        time += 1;

    }

    
    update();

    
    var terminate = setInterval(function() {
        for (var k = 0; k < settings.speed; k++) {
            update();
        }
    }, settings.delay);
    



    var handleChanges = specification.reduce((acc, spec) => {
        acc[spec.name] = (value) => {
            if (spec.shaderPrograms.includes["compute"]) {
                gl.useProgram(shaderProgramCompute);
                if (spec.type === "float") {
                    gl.uniform1f(settingsUniformLocationsCompute.find((e) => e.name === spec.name).location, value);
                }
                else if (spec.type === "int") {
                    gl.uniform1i(settingsUniformLocationsCompute.find((e) => e.name === spec.name).location, value);
                }
            }
            else if (spec.shaderPrograms.includes["color"]) {
                gl.useProgram(shaderProgramColor);
                if (spec.type === "float") {
                    gl.uniform1f(settingsUniformLocationsColor.find((e) => e.name === spec.name).location, value);
                }
                else if (spec.type === "int") {
                    gl.uniform1i(settingsUniformLocationsColor.find((e) => e.name === spec.name).location, value);
                }
            }
            else {
                clearInterval(terminate);
                rerender();
            }
            setSettings({...settings, [spec.name]: value});
        };
        return(acc);
    }
    );

    setHandleChanges(handleChanges);

    return(terminate);
}


export {launch};