

var Str = (j) => String(j);
var StrF = (j) => j.toFixed(1);

var defaultSpecification = {
    group: {
        name: "settings",
        displayName: "Settings",
        subgroups: [
            {
                name: "sim",
                displayName: "Simulation",
                subgroups: []
            },
            {
                name: "input",
                displayName: "Input",
                subgroups: [{
                        name: "basic",
                        displayName: "Basic",
                        subgroups: []
                    },
                    {
                        name: "advanced",
                        displayName: "Advanced",
                        subgroups: []
                    }
                ]
            },
            {
                name: "model",
                displayName: "Model",
                subgroups: [{
                        name: "basic",
                        displayName: "Basic",
                        subgroups: []
                    },
                    {
                        name: "advanced",
                        displayName: "Advanced",
                        subgroups: []
                    }
                ]
            },
            {
                name: "visual",
                displayName: "Visualization",
                subgroups: [{
                    name: "basic",
                    displayName: "Basic",
                    subgroups: []
                },
                {
                    name: "advanced",
                    displayName: "Advanced",
                    subgroups: []
                }
            ]
            }
        ]
    },
    vars: [
        {
            name: "width",
            displayName: "Width",
            uniformName: "width",
            shaderPrograms: ["compute", "color", "vertex"],
            restartOnChange: true,
            type: "int",
            uniformType: "float",
            admit: (x) => ((typeof x === "number" && Number.isInteger(x)) && (x >= 1) && (x <= 3000)),
            defaultValue: 400,
            description: "The width of the simulated grid.",
            group: "/settings/sim"
        },
        {
            name: "height",
            displayName: "Height",
            uniformName: "height",
            shaderPrograms: ["compute", "color", "vertex"],
            restartOnChange: true,
            type: "int",
            uniformType: "float",
            admit: (x) => ((typeof x === "number" && Number.isInteger(x)) && (x >= 1) && (x <= 3000)),
            defaultValue: 400,
            description: "The height of the simulated grid.",
            group: "/settings/sim"
        },
        {
            name: "inputRadius",
            displayName: "Radius of input",
            restartOnChange: true,
            type: "int",
            admit: (x) => ((typeof x === "number" && Number.isInteger(x)) && (x >= 1)),
            defaultValue: 20,
            description: "The radius of the input in grid units.",
            group: "/settings/input/basic"
        },
        {
            name: "inputStrength",
            displayName: "Strength of input",
            uniformName: "inputStrength",
            shaderPrograms: ["compute"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => (typeof x === "number"),
            defaultValue: 10.0,
            description: "The strength of the input.",
            group: "/settings/input/basic"
        },
        {
            name: "colorSensitivity",
            displayName: "Color sensitivity",
            uniformName: "colorSensitivity",
            shaderPrograms: ["color"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => ((typeof x === "number") && (x >= 0)),
            defaultValue: 10.0,
            description: "A factor that values are multiplied by before the corresponding color is computed.",
            group: "/settings/visual/basic"
        },
        {
            name: "colorMixRatio",
            displayName: "Secondary color sensitivity",
            uniformName: "colorMixRatio",
            shaderPrograms: ["color"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => ((typeof x === "number") && (x >= 0)),
            defaultValue: 0.1,
            description: "A factor that values are multiplied by before computing the secondary color.",
            group: "/settings/visual/basic"
        },
        {
            name: "colorExponent",
            displayName: "Color exponent",
            uniformName: "colorExponent",
            shaderPrograms: ["color"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => ((typeof x === "number") && (x >= 0)),
            defaultValue: 1.0,
            description: "An exponent involved in the computation of the color for a value.",
            group: "/settings/visual/basic"
        },
        {
            name: "colorMixExponent",
            displayName: "Secondary color exponent",
            uniformName: "colorMixExponent",
            shaderPrograms: ["color"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => ((typeof x === "number") && (x >= 0)),
            defaultValue: 1.0,
            description: "An exponent involved in the computation of the secondary color for a value.",
            group: "/settings/visual/basic"
        },
        {
            name: "colorCap",
            displayName: "Maximum color brightness",
            uniformName: "colorCap",
            shaderPrograms: ["color"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => ((typeof x === "number") && (x >= 0)),
            defaultValue: 1.0,
            description: "An upper limit to the possible brightness of displayed colors.",
            group: "/settings/visual/basic"
        },
        {
            name: "colorPattern",
            displayName: "Color pattern",
            uniformName: "colorPattern",
            shaderPrograms: ["color"],
            restartOnChange: false,
            type: "int",
            uniformType: "int",
            admit: (x) => ((typeof x === "number" && Number.isInteger(x)) && (0 <= x) && (x <= 6)),
            defaultValue: 0,
            description: "Values from 0 to 5, cycles through the differnet combinations of primary and secondary colors, as well as inverted versions.",
            group: "/settings/visual/basic"
        },
        {
            name: "scaleT",
            displayName: "Time step",
            uniformName: "scaleT",
            shaderPrograms: ["compute"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => ((typeof x === "number") && (x >= 0)),
            defaultValue: 0.05,
            description: "The size of the discretized time steps in the iteration.",
            group: "/settings/sim"
        },
        {
            name: "scaleX",
            displayName: "Scale in X axis",
            uniformName: "scaleX",
            shaderPrograms: ["compute"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => ((typeof x === "number") && (x >= 0)),
            defaultValue: 1.0,
            description: "The scale factor in direction of the X axis.",
            group: "/settings/sim"
        },
        {
            name: "scaleY",
            displayName: "Scale in Y axis",
            uniformName: "scaleY",
            shaderPrograms: ["compute"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => ((typeof x === "number") && (x >= 0)),
            defaultValue: 1.0,
            description: "The scale factor in direction of the Y axis.",
            group: "/settings/sim"
        },
        {
            name: "offsetX",
            displayName: "Offset in X axis",
            uniformName: "offsetX",
            shaderPrograms: ["compute"],
            type: "float",
            uniformType: "float",
            admit: (x) => (typeof x === "number"),
            defaultValue: 0.0,
            description: "The offset in direction of the X axis.",
            group: "/settings/sim"
        },
        {
            name: "offsetY",
            displayName: "Offset in Y axis",
            uniformName: "offsetY",
            shaderPrograms: ["compute"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => (typeof x === "number"),
            defaultValue: 0.0,
            description: "The offset in direction of the Y axis.",
            group: "/settings/sim"
        },
        {   
            name: "laplace",
            displayName: "laplace",
            uniformName: "laplace",
            shaderPrograms: ["compute"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => (typeof x === "number"),
            defaultValue: 1.0,
            description: "The coefficient of the laplacian.",
            group: "/settings/model/basic"
        },
        {   
            name: "identity",
            displayName: "identity",
            uniformName: "identity",
            shaderPrograms: ["compute"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => (typeof x === "number"),
            defaultValue: 1.0,
            description: "The coefficient of the identity term.",
            group: "/settings/model/basic"
        },
        {   
            name: "derivative",
            displayName: "derivative",
            uniformName: "derivative",
            shaderPrograms: ["compute"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => (typeof x === "number"),
            defaultValue: 1.0,
            description: "The coefficient of the time derivative.",
            group: "/settings/model/basic"
        },
        {   
            name: "cubic",
            displayName: "cubic",
            uniformName: "cubic",
            shaderPrograms: ["compute"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => (typeof x === "number"),
            defaultValue: 1.0,
            description: "The coefficient of the cubic nonlinearity.",
            group: "/settings/model/basic"
        },
        {   
            name: "noiseStrength",
            displayName: "Noise strength",
            uniformName: "noiseStrength",
            shaderPrograms: ["compute"],
            restartOnChange: false,
            type: "float",
            uniformType: "float",
            admit: (x) => (typeof x === "number"),
            defaultValue: 0.0,
            description: "The coefficient of the gaussian noise.",
            group: "/settings/model/basic"
        },
        {   
            name: "speed",
            displayName: "Iterations per frame",
            restartOnChange: true,
            type: "int",
            admit: (x) => (((typeof x === "number") && Number.isInteger(x)) && (x >= 1)),
            defaultValue: 1,
            description: "The number of iterations of the compuation performed before a new frame is rendered.",
            group: "/settings/sim"
        },
        {   
            name: "delay",
            displayName: "Minimum frame interval",
            restartOnChange: true,
            type: "int",
            admit: (x) => ((typeof x === "number" && Number.isInteger(x)) && (x >= 0)),
            defaultValue: 1,
            description: "The number of milliseconds waited before the next frame is rendered.",
            group: "/settings/sim"
            
        },
        {   
            name: "boundaryCondition",
            displayName: "Boundary Condition",
            uniformName: "boundaryCondition",
            shaderPrograms: ["compute"],
            restartOnChange: false,
            type: "int",
            uniformType: "int",
            admit: (x) => ((typeof x === "number" && Number.isInteger(x)) && (x >= 0) && (x <= 2)),
            defaultValue: 0,
            description: `If 0 then we are on a torus, if 1 then the boundary always has value zero, 
                            and if 2 then the boundary has value 0 with a circular shape.`,
            group: "/settings/model/advanced"
        },
        {   
            name: "valueDimensions",
            displayName: "Number of dimensions",
            restartOnChange: true,
            type: "int",
            admit: (x) => ((typeof x === "number" && Number.isInteger(x)) && (x >= 0)),
            defaultValue: 2,
            description: `If N, then the canvas is split into N vertically stacked sections 
                            which are each seperate simulation grids with values u_1 to u_N.`,
            group: "/settings/sim"
        },
        {   
            name: "equation",
            displayName: "Equation",
            restartOnChange: true,
            type: "string",
            admit: (x) => (typeof x === "string"),
            defaultValueGenerator: ((valueDimensions) => ([...Array(valueDimensions).keys()].map((j) => 
            `# \n ` + `u_` + Str(j+1) + `_tt = `
                + `laplace * (u_` + Str(j+1) + `_xx + u_` + Str(j+1) + `_yy)  \n `
                + `- identity * u_` + Str(j+1) + ` \n `
                + `- derivative * u_` + Str(j+1) + `_t \n `
                + `- cubic * u_` + Str(j+1) + ` * u_` + Str(j+1) + ` * u_` + Str(j+1) + ` \n `
                + `+ noiseStrength * noise \n `
                + `+ force; \n `).join(""))),
            description: `For the number of dimensions being N, this should contain N+1 sections, 
                        each separated by a hash character '#', that contain GLSL code. The most important available variables are the following: \n
                        u_1 to u_N: value at this grid point in the corresponding section. \n
                        u_1_t to u_N_t: corresponding time derivative. \n
                        u_1_tt to u_N_tt: corresponding second order time derivative. \n
                        t: time \n
                        x, X: x-coordinate with respect to center and with respect to left edge. \n
                        y, Y: y-coordinate with respect to center and with respect to bottom edge. \n
                        Let j being any integer between 1 and N. The following spacial derivatives are available: \n
                        u_j_x, u_j_y, u_j_xx, u_j_yy, u_j_xy, u_j_yx as well as Delta_u_j for the laplacian. \n
                        It is possible to define auxillary variables in the first section.`,
            group: "/settings/model/advanced"
        },
        {   
            name: "displayedQuantity",
            displayName: "Displayed quantities",
            restartOnChange: true,
            type: "string",
            admit: (x) => (typeof x === "string"),
            defaultValueGenerator: (valueDimensions) => "[" + [...Array(valueDimensions).keys()].map((j) => "`u_" + Str(j+1) + "`").join(", ") + "]",
            description: `This determines which value is displayed in each section of the display. 
                            By default u_j is displayed in the j-th section, where j is inbetween 1 and N.
                            The format is consist of a list of strings, where each string is a GLSL expression that should be defined, 
                            for example by the equation. 
                            By adding '1i' at the beginning of the string, the display switches to complex number mode. 
                            Then if for example the j-th string is '1i 2.0*u_3', then in the j-th section the displayed real part will be u_j 
                            and the displayed imaginary part will be 2.0 * u_3.`,
            group: "/settings/visual/advanced"
        },
        {   
            name: "initialDataFunction",
            displayName: "Inital Data",
            restartOnChange: true,
            type: "string",
            admit: (x) => (typeof x === "string"),
            defaultValueGenerator: (valueDimensions) => "(x,y) => [" + [...Array(valueDimensions).keys()].map((j) => "[0.0,0.0]").join(",") + "]",
            description: `The grid will be initialized to the values of this function. 
                            Here x and y are the same variables as in the equation.
                            The format is that of a function mapping (x, y) to a list of length N where N is the number of dimensions.
                            Each entry in the list corresponds to a section, and contains a pair of Javascript expressions that give the value for the 
                            initial value and initial time derivative at the point (x, y).`,
            group: "/settings/input/advanced"
        },
        {   
            name: "useCellularAutomatonRule",
            displayName: "Apply Cellular Automaton Rule",
            restartOnChange: true,
            type: "string",
            admit: (x) => (typeof x === "string"),
            defaultValue: "",
            description: `Replaces the equation with one respondin to a celluar automaton corresponding 
                            to the one given, in the notation B[numbers admissible for birth]S[numbers admissible for survival].
                            As an example B3S23 is Conway's game of life.`,
            group: "/settings/model/basic"
        }
    ]
};


var fillDefaultSettings = (specification) => (settings) => specification.vars.reduce((acc, obj) => {
    if (settings.hasOwnProperty(obj.name)) {
        acc[obj.name] = settings[obj.name];
        return(acc);
    }
    else if (obj.hasOwnProperty('defaultValue')) {
        acc[obj.name] = settings[obj.name] ? settings[obj.name] : obj.defaultValue;
        return(acc);
    }
    else if (obj.hasOwnProperty('defaultValueGenerator')) {
        if (settings.hasOwnProperty('valueDimensions')) {
            acc[obj.name] = obj.defaultValueGenerator(settings.valueDimensions);
        }
        else {
            acc[obj.name] = obj.defaultValueGenerator(specification.vars.find((e) => e.name == 'valueDimensions').defaultValue);
        }
    }
    return(acc);
}, {});

var defaultSettings = fillDefaultSettings(defaultSpecification)({});

export {defaultSpecification, defaultSettings, fillDefaultSettings};