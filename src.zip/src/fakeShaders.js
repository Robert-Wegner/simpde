
var Str = (j) => String(j);
var StrF = (j) => j.toFixed(1);



var vertexShaderSource = (vars, settings) => `#version 300 es
    precision highp float;

    in vec2 a_position;

    in vec2 a_texCoord;
    out vec2 v_texCoord;

    `
    +
    vars.reduce((acc, spec) => acc + 
        ((spec.hasOwnProperty("shaderPrograms") && spec.shaderPrograms.includes("vertex")) ? 
        "uniform " + spec.uniformType + " " + spec.uniformName + "; \n"
        : ""), "")
    +
    `
    uniform float u_flipY;
    
    void main() {
       // convert the rectangle from pixels to 0.0 to 1.0
       vec2 zeroToOne = a_position / vec2(height, height);
    
       // convert from 0->1 to 0->2
       vec2 zeroToTwo = zeroToOne * 2.0;
    
       // convert from 0->2 to -1->+1 (clipspace)
       vec2 clipSpace = zeroToTwo - 1.0;
    
       gl_Position = vec4(clipSpace * vec2(1, u_flipY), 0, 1);
    
       // pass the texCoord to the fragment shader
       // The GPU will interpolate this value between points.
       v_texCoord = a_texCoord;
    }`;

var fragmentShaderComputeSource = (vars, settings) => `#version 300 es
    precision highp float;

    in vec2 v_texCoord;

    out vec4 outColor;
            
    uniform sampler2D image;
    uniform sampler2D image_input;

    uniform vec2 mouse;

    uniform float randSeed;
 
    `
    +
    vars.reduce((acc, spec) => acc + 
        ((spec.hasOwnProperty("shaderPrograms") && spec.shaderPrograms.includes("compute")) ? 
        "uniform " + spec.uniformType + " " + spec.uniformName + "; \n"
        : ""), "")
    +
    `

    float rand(vec2 co){
        return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
    }

    float gaussian(float a) {
        float res1 = rand(v_texCoord.xy * vec2(a + 10.0));
        res1 = rand(vec2(res1, randSeed));
        float res2 = rand(v_texCoord.xy * vec2(100.0));
        res2 = rand(vec2(res2, randSeed));
        float res3 = rand(v_texCoord.xy * vec2(1000.0));
        res3 = rand(vec2(res3, randSeed));
        float res4 = rand(v_texCoord.yx * vec2(a + 11.0));
        res4 = rand(vec2(res4, randSeed));
        float res5 = rand(v_texCoord.yx * vec2(101.0));
        res5 = rand(vec2(res5, randSeed));
        float res6 = rand(v_texCoord.yx * vec2(1001.0));
        res6 = rand(vec2(res6, randSeed));

        return (res1 + res2 + res3 - res4 - res5 - res6) / 6.0;
    }


    vec2 modulo(vec2 X, vec2 Y) {
        return vec2(X - floor(X / Y) * Y);
    }
    
    void main() {

        vec4 data = texture(image, v_texCoord);

        float force = 0.0;

        float x = 0.0;
        float y = 0.0;
        float X = 0.0;
        float Y = 0.0;

        vec2 shift = vec2(0.0, 0.0);

        float t = data.b;

        float noise = 0.0;
    `
    + 
    `
        float h = ` + StrF(1 / settings.valueDimensions) + `;

        int j = int(floor(v_texCoord.y / h));
        int rev_j = ` + Str(settings.valueDimensions-1) + ` - j;

    `
    + [...Array(settings.valueDimensions).keys()].map((j) =>
    ` 
        vec2 texCoord_` + Str(j+1) + ` = v_texCoord + vec2(0.0, `+ `(` + StrF(j) + ` - float(j)) * h);
        
    `).join("")
    + [...Array(settings.valueDimensions).keys()].map((j) =>
    `
        float u_` + Str(j+1) + ` = 0.0;
        float u_` + Str(j+1) + `_t = 0.0;
        float u_` + Str(j+1) + `_tt = 0.0;
        float u_` + Str(j+1) + `_x = 0.0;
        float u_` + Str(j+1) + `_y = 0.0;
        float u_` + Str(j+1) + `_xx = 0.0;
        float u_` + Str(j+1) + `_yy = 0.0;
        float u_` + Str(j+1) + `_xy = 0.0;
        float u_` + Str(j+1) + `_yx = 0.0;
        float Delta_u_` + Str(j+1) + ` = 0.0;
        
    `).join("")
    +
    `
        float A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W;
        vec2 pixelSize = vec2(1.0 / height, 1.0 / height);


        if  ((boundaryCondition == 0) 
            || ((boundaryCondition == 1) && ((texCoord_1.x > 0.6 * pixelSize.x) && (texCoord_1.y > 0.6 * pixelSize.y)
                                            && (texCoord_1.x < 1.0 - 0.4 * pixelSize.x) && (texCoord_1.y < h - 0.4 * pixelSize.y)))
            || ((boundaryCondition == 2) && (distance(texCoord_1, vec2(0.5, 0.5 * h)) < 0.5 * h - 1.0 * min(pixelSize.x, pixelSize.y)))
            || ((boundaryCondition == 3) && ((texCoord_1.x > 0.6 * pixelSize.x) && (texCoord_1.x < 1.0 - 0.4 * pixelSize.x)))) {
        `
        + [...Array(settings.valueDimensions).keys()].map((j) =>
            `
                shift = vec2(0, `+ StrF(settings.valueDimensions - 1 - j) + ` * h); 

                u_` + Str(j+1) + ` = texture(image, shift + modulo(texCoord_1, vec2(1.0,h))).r;
                u_` + Str(j+1) + `_t = texture(image, shift + modulo(texCoord_1, vec2(1.0,h))).g;

                float u_` + Str(j+1) + `_above = texture(image, shift + modulo(texCoord_1 + vec2(0, pixelSize.y), vec2(1.0,h))).r;
                float u_` + Str(j+1) + `_below = texture(image, shift + modulo(texCoord_1 + vec2(0, -pixelSize.y), vec2(1.0,h))).r;
                float u_` + Str(j+1) + `_right = texture(image, shift + modulo(texCoord_1 + vec2(pixelSize.x, 0), vec2(1.0,h))).r;
                float u_` + Str(j+1) + `_left = texture(image, shift + modulo(texCoord_1 + vec2(-pixelSize.x, 0), vec2(1.0,h))).r;
                float u_` + Str(j+1) + `_right_above = texture(image, shift + modulo(texCoord_1 + vec2(pixelSize.x, pixelSize.y), vec2(1.0,h))).r;
                float u_` + Str(j+1) + `_right_below = texture(image, shift + modulo(texCoord_1 + vec2(pixelSize.x, -pixelSize.y), vec2(1.0,h))).r;
                float u_` + Str(j+1) + `_left_above = texture(image, shift + modulo(texCoord_1 + vec2(-pixelSize.x, pixelSize.y), vec2(1.0,h))).r;
                float u_` + Str(j+1) + `_left_below = texture(image, shift + modulo(texCoord_1 + vec2(-pixelSize.x, -pixelSize.y), vec2(1.0,h))).r;

                float Delta_u_` + Str(j+1) + ` = (u_` + Str(j+1) + `_right - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_left) / (2.0 * scaleX)
                                + (u_` + Str(j+1) + `_above - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_below) / (2.0 * scaleY)
                                + (u_` + Str(j+1) + `_right_above - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_left_below) / (2.0 * sqrt(2.0) * scaleX)
                                + (u_` + Str(j+1) + `_left_above - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_right_below) / (2.0 * sqrt(2.0) * scaleY);
                
                if (noiseStrength != 0.0) {
                    noise = gaussian(1.0 + randSeed);
                }
        

                u_` + Str(j+1) + `_x = (u_` + Str(j+1) + `_right - u_` + Str(j+1) + `_left) / (2.0 * scaleX);
                u_` + Str(j+1) + `_y = (u_` + Str(j+1) + `_above - u_` + Str(j+1) + `_below) / (2.0 * scaleY);
                u_` + Str(j+1) + `_xx = (u_` + Str(j+1) + `_right - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_left) / scaleX;
                u_` + Str(j+1) + `_yy = (u_` + Str(j+1) + `_above - 2.0 * u_` + Str(j+1) + ` + u_` + Str(j+1) + `_below) / scaleY;
                u_` + Str(j+1) + `_xy = (u_` + Str(j+1) + `_right_above - u_` + Str(j+1) + `_left_above - u_` + Str(j+1) + `_right_below + u_` + Str(j+1) + `_left_below) / (4.0 * scaleX);
                u_` + Str(j+1) + `_yx = u_` + Str(j+1) + `_xy;
                x = offsetX + (texCoord_1.x - 0.5) * height * scaleX;
                y = offsetY + (texCoord_1.y - 0.5 * h) * height * scaleY;

                X = texCoord_1.x * height * scaleX;
                Y = texCoord_1.y * height * scaleY;

            `).join("")
            + `
                force = inputStrength * texture(image_input, modulo(texCoord_1 + vec2(0.0, float(j) * h) 
                    + pixelSize * (mouse + vec2(0.5, 0.5) * vec2(height, height)), vec2(1.0,1.0))).b;
            `
            + (settings.equation).split("#")[0].replace(/(\r\n|\n|\r)/gm, "")
            + [...Array(settings.valueDimensions).keys()].map((j) =>
                `
                    if (rev_j == ` + Str(j) + `) {
                        `
                        +
                        (settings.equation).split("#")[j+1].replace(/(\r\n|\n|\r)/gm, "")
                        +
                        `u_` + Str(j+1) + `_t = u_` + Str(j+1) + `_t + scaleT * u_` + Str(j+1) + `_tt;
                        u_` + Str(j+1) + ` = u_` + Str(j+1) + ` + scaleT * u_` + Str(j+1) + `_t;

                        t += scaleT;
                        outColor = vec4(u_` + Str(j+1) + `, u_` + Str(j+1) + `_t, t, ` 
                        + ((settings.useCustomEquation) ? 
                            (eval(settings.displayedQuantity)[j].substring(0,2) === "1i" ?
                                eval(settings.displayedQuantity)[j].substring(2)
                                :
                                eval(settings.displayedQuantity)[j]
                            )
                            : 
                            `u_` + Str(j+1)) + `);
                        
                    }
                `).join("")
            + `
            } 
        `
    +
    `
        else {
        `
        + [...Array(settings.valueDimensions).keys()].map((j) =>
        `
            if (j == ` + Str(j) + `) {
                u_` + Str(j+1) + `_tt = 0.0;
                u_` + Str(j+1) + `_t = 0.0;
                u_` + Str(j+1) + ` = 0.0;

                t += scaleT;
                outColor = vec4(u_` + Str(j+1) + `, u_` + Str(j+1) + `_t, t, 0.0);
            }`).join("")
    +   `}
    }`;


var fragmentShaderColorSource = (vars, settings) => `#version 300 es
    #define PI radians(180.0)
    precision highp float;

    in vec2 v_texCoord;

    out vec4 outColor;
            
    uniform sampler2D image_color;

    `
    +
    vars.reduce((acc, spec) => acc + 
        ((spec.hasOwnProperty("shaderPrograms") && spec.shaderPrograms.includes("color")) ? 
        "uniform " + spec.uniformType + " " + spec.uniformName + "; \n"
        : ""), "")
    +
    `


    vec2 modulo(vec2 X, vec2 Y) {
        return vec2(X - floor(X / Y) * Y);
    }

    float moduloF(float X, float Y) {
        return X - floor(X / Y) * Y;
    }

    float atan2(float x, float y)
    {
        if (abs(x) > abs(y)) {
            return atan(y, x);
        }
        else {
            return PI / 2.0 - atan(x, y);
        }
    }

    vec4 colorCurve(float phase) {

        float rad = 1.0 / sin(PI/6.0) * cos(PI/3.0) 
                        / cos(moduloF(phase+PI/4.0, 2.0*PI/3.0) - PI/3.0);

        float a = atan(sqrt(2.0));

        float q = cos(phase)*(1.0 + colorMixRatio*(rad - 1.0));
        float p = sin(phase)*(1.0 + colorMixRatio*(rad - 1.0));

        float cr = 1.0/3.0 + 1.0/sqrt(6.0) * (
            0.5 * q * (1.0 - cos(a))
            + 0.5 * p * (1.0 + cos(a))
        );
        float cg = 1.0/3.0 - 1.0/sqrt(6.0) * (
            0.5 * q * (1.0 + cos(a))
            + 0.5 * p * (1.0 - cos(a))
        );
        float cb = 1.0/3.0 + 1.0/sqrt(6.0) * (
            1.0 / sqrt(2.0) * (q - p) * sin(a)
        );

        float rescaling = 1.0 / pow(max(max(cr, cg), cb), colorMixExponent);
        return vec4(rescaling*cr, rescaling*cg, rescaling*cb, 1.0) ;
    }

    void main() {

        float h = ` + StrF(1 / settings.valueDimensions) + `;
        int j = int(floor(v_texCoord.y / h));
        int rev_j = ` + Str(settings.valueDimensions-1) + ` - j;

        int isComplex = 0;
        
        vec4 data = texture(image_color, v_texCoord);

        vec4 color = vec4(0.5, 0.5, 0.5, 1.0);
        `
        
        +
        [...Array(settings.valueDimensions).keys()].map((j) =>
            `
            if (rev_j == ` + Str(j) + `) {
                `
                +
                ((eval(settings.displayedQuantity)[j].substring(0,2) === "1i") ?
                `isComplex = 1;`
                :
                `isComplex = 0;`)
                +
                `
                
            }`
        ).join("")
        +
        `
        if (isComplex == 0) {
            float u_raw = data.a;
            float u = sign(u_raw) * pow(colorSensitivity * abs(u_raw),colorExponent);
            float v = sign(u) * pow(colorMixRatio * abs(u),colorMixExponent);

            if (colorPattern == 0) {
                if (u >= 0.0) {
                    color = vec4(   (1.0 - colorCap * (1.0 / (1.0 + u))),
                                    (1.0 - colorCap * (1.0 / (1.0 + v))),
                                    1.0 - colorCap,
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   1.0 - colorCap, 
                                    (1.0 - colorCap * (1.0 / (1.0 - v))),
                                    (1.0 - colorCap * (1.0 / (1.0 - u))),
                                    1.0);
                }
            }
            else if (colorPattern == 1) {
                if (u >= 0.0) {
                    color = vec4(   1.0 - colorCap,
                                    (1.0 - colorCap * (1.0 / (1.0 + u))),
                                    (1.0 - colorCap * (1.0 / (1.0 + v))),
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   (1.0 - colorCap * (1.0 / (1.0 - u))), 
                                    1.0 - colorCap,
                                    (1.0 - colorCap * (1.0 / (1.0 - v))),
                                    1.0);
                }
            }
            else if (colorPattern == 2) {
                if (u >= 0.0) {
                    color = vec4(   (1.0 - colorCap * (1.0 / (1.0 + v))),
                                    (1.0 - colorCap * (1.0 / (1.0 + u))),
                                    1.0 - colorCap,
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   (1.0 - colorCap * (1.0 / (1.0 - v))),
                                    1.0 - colorCap,
                                    (1.0 - colorCap * (1.0 / (1.0 - u))), 
                                    1.0);
                }
            }
            else if (colorPattern == 3) {
                if (u >= 0.0) {
                    color = vec4(   colorCap * (1.0 / (1.0 + u)),
                                    colorCap * (1.0 / (1.0 + v)),
                                    colorCap,
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   colorCap, 
                                    colorCap * (1.0 / (1.0 - v)),
                                    colorCap * (1.0 / (1.0 - u)),
                                    1.0);
                }
            }
            else if (colorPattern == 4) {
                if (u >= 0.0) {
                    color = vec4(   colorCap * 1.0,
                                    colorCap * (1.0 / (1.0 + u)),
                                    colorCap * (1.0 / (1.0 + v)),
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   colorCap * (1.0 / (1.0 - u)),
                                    colorCap * 1.0,
                                    colorCap * (1.0 / (1.0 - v)),
                                    1.0);
                }
            }
            else if (colorPattern == 5) {
                if (u >= 0.0) {
                    color = vec4(   colorCap * (1.0 / (1.0 + v)),
                                    colorCap * (1.0 / (1.0 + u)),
                                    colorCap * 1.0,
                                    1.0);
                }
                if (u < 0.0) {
                    color = vec4(   colorCap * (1.0 / (1.0 - v)), 
                                    colorCap * 1.0,
                                    colorCap * (1.0 / (1.0 - u)),
                                    1.0);
                }
            }
        }
        if (isComplex == 1) {
            float real = data.r;
            float imag = data.a;
            float mag = sqrt(real*real + imag*imag);
            float phase = atan2(real, imag);

            float u = pow(colorSensitivity * abs(mag), colorExponent);

            color = vec4(1.0 - 1.0 / (1.0 + u), 
                        1.0 - 1.0 / (1.0 + u),
                        1.0 - 1.0 / (1.0 + u), 
                        1.0) * colorCurve(phase);
        }
                
        outColor = color;
    }`;

export {vertexShaderSource, fragmentShaderComputeSource, fragmentShaderColorSource}