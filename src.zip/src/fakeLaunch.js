import {makeTextures, makeInputTexture, makeShaderPrograms} from './fakeMakerFunctions';


function launch(canvas, specification, settings, setUpdateAppliedSettings){

    var width = settings.width;
    var height = settings.height;
    var gl = canvas.getContext("webgl2");

    if (!gl) {
        console.log('your browser/OS/drivers do not support WebGL2');
    } else {
        console.log('webgl2 works!');
    }
    gl.getExtension( 'EXT_color_buffer_float' );    
    
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);

    console.log(gl);

    var nb_textures = 3;
    var textures = [];
    var framebuffers = [];

    var {textures, framebuffers} = makeTextures(gl, nb_textures, specification, settings);

    var inputTexture = makeInputTexture(gl, specification, settings);

    var {shaderProgramCompute, shaderProgramColor} = makeShaderPrograms(gl, specification, settings);


    gl.useProgram(shaderProgramCompute);

    var settingsUniformLocationsCompute = specification.vars.filter(
        (spec) => (spec.shaderPrograms && spec.shaderPrograms.includes("compute"))
    ).map(
        (spec) => {
            var location = gl.getUniformLocation(shaderProgramCompute, spec.uniformName);
            return({name: spec.name,
                    location: gl.getUniformLocation(shaderProgramCompute, spec.uniformName)})
        }
    );

    gl.useProgram(shaderProgramCompute);
    var settingsUniformLocationsColor = specification.vars.filter(
        (spec) => (spec.shaderPrograms && spec.shaderPrograms.includes("color"))
    ).map(
        (spec) => {
            var location = gl.getUniformLocation(shaderProgramColor, spec.uniformName);
            return({name: spec.name,
                    location: gl.getUniformLocation(shaderProgramColor, spec.uniformName)})
        }
    );


    gl.useProgram(shaderProgramCompute);
    settingsUniformLocationsCompute.map((obj) => {
        if (specification.vars.find((e) => e.name == obj.name).uniformType === "float") {
            gl.uniform1f(obj.location, settings[obj.name])
        }
        else if (specification.vars.find((e) => e.name == obj.name).uniformType === "int") {
            gl.uniform1i(obj.location, settings[obj.name])
        }
    });
    gl.useProgram(shaderProgramColor);
    settingsUniformLocationsColor.map((obj) => {
        if (specification.vars.find((e) => e.name == obj.name).uniformType === "float") {
            gl.uniform1f(obj.location, settings[obj.name])
        }
        else if (specification.vars.find((e) => e.name == obj.name).uniformType === "int") {
            gl.uniform1i(obj.location, settings[obj.name])
        }
    });

    var otherUniformLocationsCompute = {
        randSeed: {uniformName: "randSeed",
            location: gl.getUniformLocation(shaderProgramCompute, "randSeed")},
        mouse: {uniformName: "mouse",
            location: gl.getUniformLocation(shaderProgramCompute, "mouse")},
        image: {uniformName: "image",
            location: gl.getUniformLocation(shaderProgramCompute, "image")},
        imageInput: {uniformName: "image_input",
            location: gl.getUniformLocation(shaderProgramCompute, "image_input")}
    };

    var otherUniformLocationsColor = {
        imageColor: {uniformName: "image_color",
            location: gl.getUniformLocation(shaderProgramColor, "image_color")}
    };

    gl.useProgram(shaderProgramCompute);
    gl.uniform1f(otherUniformLocationsCompute.randSeed.location, 0);
    gl.uniform2f(otherUniformLocationsCompute.mouse.location, 0, 0);
    gl.uniform1i(otherUniformLocationsCompute.image.location, 0);
    gl.uniform1i(otherUniformLocationsCompute.imageInput.location, 1);

    gl.useProgram(shaderProgramColor);
    gl.uniform1i(otherUniformLocationsColor.imageColor.location, 0);


    var toggle = 1.0;

    gl.useProgram(shaderProgramCompute);

    var mouseLocation = otherUniformLocationsCompute.mouse.location;
    var inputStrengthLocation = settingsUniformLocationsCompute.find((e) => e.name == "inputStrength").location;
    gl.uniform1f(inputStrengthLocation, 0.0);
    
    var onmousedown = function(e) {
        gl.useProgram(shaderProgramCompute);
        var X = e.clientX || e.targetTouches[0].clientX;
        var Y = e.clientY || e.targetTouches[0].clientY;
        var rect = canvas.getBoundingClientRect();
        var x = (X-rect.x) * width / rect.width;
        var y = (Y-rect.y) * height / rect.height;
        gl.uniform2f(mouseLocation, -x, y);
        gl.uniform1f(inputStrengthLocation, toggle * settings.inputStrength);
        toggle *= -1.0;
    }
    var onmouseup = function(e) {
        gl.useProgram(shaderProgramCompute);
        gl.uniform1f(inputStrengthLocation, 0.0);

    }
    var onmousemove = function(e) {
        gl.useProgram(shaderProgramCompute);
        var X = e.clientX || e.targetTouches[0].clientX;
        var Y = e.clientY || e.targetTouches[0].clientY;
        var rect = canvas.getBoundingClientRect();
        var x = (X-rect.x) * width / rect.width;
        var y = (Y-rect.y) * height / rect.height;
        gl.uniform2f(mouseLocation, -x, y);

    }

    canvas.onmousedown = onmousedown;
    canvas.onmousemove = onmousemove;
    canvas.onmouseup = onmouseup;
    if (window.navigator.msPointerEnabled) {
        canvas.addEventListener("MSPointerDown", onmousedown, false);
        canvas.addEventListener("MSPointerMove", onmousemove, false);
        canvas.addEventListener("MSPointerUp", onmouseup, false);
    }
    else {
        canvas.addEventListener("touchstart", onmousedown, false);
        canvas.addEventListener("touchmove", onmousemove, false);
        canvas.addEventListener("touchend", onmouseup, false);
    }


    

    var time = 0;
    gl.useProgram(shaderProgramCompute);

    gl.bindTexture(gl.TEXTURE_2D, textures[time % 2]);
    gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffers[(time + 1) % 2]);
    
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, width, height);
    gl.drawArrays(gl.TRIANGLES, 0, 6);

    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, inputTexture);

    var update = function(){

        gl.useProgram(shaderProgramCompute);
        if (settings.noise > 0.0) {
            gl.uniform1f(otherUniformLocationsCompute.randSeed.location, Math.random());
        }

        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, textures[time % 2]);
        
        
        gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffers[(time + 1) % 2]);
        gl.viewport(0, 0, width, height);
        gl.drawArrays(gl.TRIANGLES, 0, 6);

        //console.timeEnd();
        //console.time();
        gl.useProgram(shaderProgramColor);

        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, textures[(time + 1) % 2]);
        

        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        gl.viewport(0, 0, width, height);
        gl.drawArrays(gl.TRIANGLES, 0, 6);

        //gl.clearColor(0.0, Math.cos(time / 300), 0.0, 1.0);
        // Clear the context with the newly set color. This is
        // the function call that actually does the drawing.
        //gl.clear(gl.COLOR_BUFFER_BIT);


        //console.timeEnd();
        time += 1;

    }

    update();

    var terminate = setInterval(function() {
        for (var k = 0; k < settings.speed; k++) {
            update();
        }
    }, settings.delay);

    //console.log(specification)

    var updateAppliedSettings = specification.vars.reduce((acc, spec) => {
        return {...acc, [spec.name]: (value) => {
            if (spec.hasOwnProperty("shaderPrograms") && spec.shaderPrograms.includes("compute")) {
                gl.useProgram(shaderProgramCompute);
                if (spec.uniformType === "float") {
                    gl.uniform1f(settingsUniformLocationsCompute.find((e) => e.name === spec.name).location, value);
                }
                else if (spec.uniformType === "int") {
                    gl.uniform1i(settingsUniformLocationsCompute.find((e) => e.name === spec.name).location, value);
                }
            }
            if (spec.hasOwnProperty("shaderPrograms") && spec.shaderPrograms.includes("color")) {
                gl.useProgram(shaderProgramColor);
                if (spec.uniformType === "float") {
                    gl.uniform1f(settingsUniformLocationsColor.find((e) => e.name === spec.name).location, value);
                }
                else if (spec.uniformType === "int") {
                    gl.uniform1i(settingsUniformLocationsColor.find((e) => e.name === spec.name).location, value);
                }
            }
            if (spec.restartOnChange && (value != settings[spec.name])) {
                clearInterval(terminate);
            }
        }};
    }, {});

    //console.log(updateAppliedSettings)
    setUpdateAppliedSettings(updateAppliedSettings);

    return(terminate);
}


export {launch};