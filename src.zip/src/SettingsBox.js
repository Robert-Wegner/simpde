
import React, { useState } from 'react';
import {InputBox} from './InputBox.js';
import {CollapsibleList} from './CollapsibleList.js';
import {colors} from './colors.js';
import { Scrollbars } from 'react-custom-scrollbars-2';




function stringifySettings(specification, settings, floatDecimals) {
    var stringifiedSettings = {};
    Object.keys(settings).forEach((key) => {
        var spec = specification.vars.find((e) => e.name == key);
        if (spec.type === "int") {
            stringifiedSettings[key] = String(settings[key]);
        }
        else if (spec.type === "float") {
            stringifiedSettings[key] = settings[key].toFixed(floatDecimals)
        }
        else {
            stringifiedSettings[key] = String(settings[key]);
        }
    });
    return(stringifiedSettings);
}

function SettingsBox(props) {

    var specification = props.specification;
    var settings = props.settings;
    
    var handleBlurs = props.handleBlurs;

    var floatDecimals = 2;
    const [stringSettings, setStringSettings] = useState(stringifySettings(specification, settings, floatDecimals));

    var recursor = (group, path, depth) => {
        var currentPath = path + "/" + group.name;
        if (group.subgroups.length > 0) {
            return (
                <CollapsibleList    title = {group.displayName} 
                                    key = {currentPath}
                                    borderColor = {(depth % 2 == 0) ? colors.cyan : colors.magenta}
                >
                    {group.subgroups.map((obj, index) => recursor(obj, currentPath, depth + 1))}
                </CollapsibleList>
            );
        }
        else {
            return(
                <CollapsibleList    title = {group.displayName} 
                                    key = {currentPath}
                                    borderColor = {(depth % 2 == 0) ? colors.cyan : colors.magenta}
                >
                    {specification.vars.filter((spec) => (spec.group == currentPath)).map((spec) => 
                    <InputBox   key = {currentPath + "/" + spec.name}    
                                spec = {spec}   
                                stringValue = {stringSettings[spec.name]} 
                                value = {settings[spec.name]}
                                handleChange = {(event) => {
                                    setStringSettings({...stringSettings, [spec.name]: event.target.value});
                                }}
                                handleBlur = {(event) => handleBlurs[spec.name](event.target.value)} />
                    )}
                </CollapsibleList>
            );
        }
    }

    return (
        <div style = {{ width: "25vw",
                        height: "90vh",
                        margin: "5px",
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"}}>
            <Scrollbars style={{
                width: "100%",
                borderTop: "1px solid " + colors.textWhite,
                borderBottom: "1px solid " + colors.textWhite,
                fontFamily: "Consolas,Monaco,Lucida Console,Liberation Mono,DejaVu Sans Mono,Bitstream Vera Sans Mono,Courier New",
            }} 
                renderThumbVertical={() => 
                <div 
                    style={{width: "1px", 
                            backgroundColor: colors.textWhite,
                            display: "none"
                    }}>
                </div>}
                renderTrackHorizontal={props => <div {...props} style={{display: 'none'}} className="track-horizontal"/>}
            >
                <div style={{overflowX: "hidden"}}>
                    {recursor(specification.group, "", 0)}       
                </div>
            </Scrollbars>
            <div    style = {{  marginTop: "5px",
                                fontSize: "1.2em", 
                                width: "15vw",
                                display: "flex", 
                                justifyContent: "center", 
                                alignItems: "center",
                                border: "2px solid " + colors.yellow,
                                cursor: "pointer"}}
                    onClick = {props.handleReset}
                    onMouseEnter = {(e) => {
                        e.target.style.textShadow = "0px 0px 3px " + colors.yellow;
                    }}
                    onMouseLeave = {(e) => {
                        e.target.style.textShadow = "";
                    }}>
                    
                Reset
            </div>
        </div>
    );
}

export {SettingsBox};
