import React, { useState, useMemo, useRef, useEffect } from 'react';
import{fillDefaultSettings} from './spec.js';
import {launch} from './fakeLaunch.js';
import {SettingsBox} from './SettingsBox.js';
import {colors} from './colors.js';

function importSettingsFromWindowHash() {
    if(window.location.hash) {
        return(JSON.parse(decodeURIComponent(window.location.hash.substring(1))));
    }
    else {
        return({});
    }
}

function exportSettingsToWindowHash(settings) {
    window.location.hash = encodeURIComponent(JSON.stringify(settings, null, 2));
}

var isDigit = (function() {
    var re = /^\d$/;
    return function(c) {
        return re.test(c);
    }
}());

function parseEquationOrders(equation) {
    console.log(equation)
    var list = [...equation.matchAll(new RegExp('u_', 'gi'))].map(a => a.index);
    var orderList = [];
    for (var k = 0; k < list.length; k++) {
        var i = list[k];
        var j = 2;
        var string = "";
        var num = -1;
        var timeOrder = 0;
        var spaceOrderX = 0;
        var spaceOrderY = 0;
        console.log(equation.slice(i+j, i+j+3));
        while ((i + j < equation.length) && isDigit(equation[i + j])) {
            string += equation[i + j];
            j += 1;
        }
        num = parseInt(string);
        if (!isNaN(num)) {
            if (equation.slice(i + j, i + j + 2) == "_t") {
                timeOrder = 1;
            }
            else if (equation.slice(i + j, i + j + 2) == "_x") {
                spaceOrderX = 1;
            }
            else if (equation.slice(i + j, i + j + 2) == "_y") {
                spaceOrderY = 1;
            }
            j += 2;
            var condition = (spaceOrderX > 0) || (spaceOrderY > 0) || (timeOrder > 0);
            while ((i + j < equation.length) && condition) {
                console.log(equation[i + j]);
                condition = false;
                if (equation[i + j] == "x") {
                    spaceOrderX += 1;
                    condition = true;
                }
                else if (equation[i + j] == "y") {
                    spaceOrderY += 1;
                    condition = true;
                }
                j += 1;
            }
            var info = [num, timeOrder, spaceOrderX, spaceOrderY];

            if (orderList.find((e) => e == info) == undefined) {
                orderList.push(info);
            }
        }
    }
    return orderList

}

function Sim(props) {
    
    var specification = props.specification;

    const [settings, setSettings] = useState(fillDefaultSettings(specification)(importSettingsFromWindowHash())); 

    console.log("orders: ", parseEquationOrders(settings.equation));
    const [updateAppliedSettings, setUpdateAppliedSettings] = useState([]);


    const [render, setRender] = useState(0);


    const canvasRef = useRef(null);

    var canvas = useMemo(() => <canvas  id='canvas' 
                                        style={{touchAction: "none",
                                                width: "70vw"}}
                                        width={settings.width} height={settings.height} ref={canvasRef} />, [render]);
    

    var setSettingsAndWindowHash = (newSettings) => {
        setSettings(newSettings);
        exportSettingsToWindowHash(newSettings);
    }

    var terminate = 0;
    useEffect(() => {
        try{
            terminate = launch(     canvasRef.current, 
                                    specification,
                                    settings,
                                    setUpdateAppliedSettings,);
        }
        catch{
            console.log("Launch failed");
        }
        return(() => {
            clearInterval(terminate)
        })
    }, [render]);

    var resetFunction = () => {clearInterval(terminate); setRender(render + 1);}

    var handleBlurs = specification.vars.reduce((acc, spec) => {
        return {...acc, [spec.name]: (value) => {
            var oldValue = settings[spec.name];
            var newValue = oldValue;
            if (spec.type === "int") {
                newValue = isNaN(parseInt(value)) ? oldValue : parseInt(value);
            }
            else if (spec.type === "float") {
                newValue = isNaN(parseFloat(value)) ? oldValue : parseFloat(value);
            }
            else if (spec.type === "string") {
                newValue = value;
            }
            if (newValue != oldValue) {
                console.log("first, ", spec)
                setSettingsAndWindowHash({...settings, [spec.name]: newValue});
                updateAppliedSettings[spec.name](newValue);
                if (spec.restartOnChange) {
                    resetFunction();
                }
            }
        }}
    }, {});

    return(
        <div id='Sim' style={{  backgroundColor: colors.gray, 
                                display: "flex",
                                flexDirection: "row",
                                alignItems: "flex-start",
                                justifyContent: "space-evenly"}}>
            {canvas}
            <SettingsBox    specification = {specification}
                            settings = {settings}   
                            handleBlurs = {handleBlurs}
                            handleReset = {resetFunction} />
        </div>
    );
}


export {Sim};